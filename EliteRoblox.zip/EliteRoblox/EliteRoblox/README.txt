Hello! Thanks for installing Elite Exec. To get started you need to install a 3rd party application. Don't worry ive made it very easy for you. Here is a tutorial on how to use it:

First run BootstrapperForEazfuscator (This may take a while, after its done you can close it)
Then open Elite (This will open instantly, Or a popup saying download runtime will appear just follow the simple steps.)
Hit Inject (Allow VoxiInject.exe to open)
Execute script (Done!)

Thank you. Elite Dev & VoxiAPI